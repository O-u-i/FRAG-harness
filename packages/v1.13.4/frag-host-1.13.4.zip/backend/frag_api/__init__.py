"""FRAG-harness FastAPI backend."""
