"""Persistence adapters."""
