"""Pydantic API contracts."""
